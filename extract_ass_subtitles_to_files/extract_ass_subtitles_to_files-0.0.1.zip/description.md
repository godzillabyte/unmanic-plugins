
Any ASS/SSA subtitle streams found in the file will be exported as *.ass files in the same directory as the original file.

:::warning
This plugin is not compatible with linking as the remote link will not have access to the original source file's directory.
:::

:::note
This Plugin does not contain a file tester to detect files that contain ASS/SSA subtitle streams.
Ensure it is pared with another Plugin.
:::
