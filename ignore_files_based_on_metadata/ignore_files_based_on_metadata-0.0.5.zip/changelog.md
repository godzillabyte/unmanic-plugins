
**<span style="color:#56adda">0.0.5</span>**
- add subtitle format section
- add audio mime type to the plugin
- make the stream search for disallowed values apply to all stream types and not just video

**<span style="color:#56adda">0.0.4</span>**
- generalize tag inclusion to video and audio streams too

**<span style="color:#56adda">0.0.3</span>**
- add test to check attachment streams tags

**<span style="color:#56adda">0.0.2</span>**
- fix __init__.py filename

**<span style="color:#56adda">0.0.1</span>**
- Initial version
