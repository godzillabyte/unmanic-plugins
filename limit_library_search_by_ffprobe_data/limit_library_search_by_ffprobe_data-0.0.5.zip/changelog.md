
**<span style="color:#56adda">0.0.5</span>**
- Use a different jsonata library that provides better stability with this plugin

**<span style="color:#56adda">0.0.4</span>**
- Bump jsonata python dependency to v0.2.5

**<span style="color:#56adda">0.0.3</span>**
- updated ffmpeg helper lib to latest version

**<span style="color:#56adda">0.0.2</span>**
- Refactor plugin to support JSONata queries of the FFprobe data

**<span style="color:#56adda">0.0.1</span>**
- Initial version
