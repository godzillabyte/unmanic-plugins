
**<span style="color:#56adda">0.0.3</span>**

- Set file_out to None instead of creating a hardlinked copy as the file_out

**<span style="color:#56adda">0.0.2</span>**

- Fix invalid plugin tags
- Update plugin priority to 99
- Fix issue with command progress parsing that would create a loop

**<span style="color:#56adda">0.0.1</span>**

- Initial version
