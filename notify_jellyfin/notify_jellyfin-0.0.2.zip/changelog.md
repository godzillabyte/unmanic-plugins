
**<span style="color:#56adda">0.0.2</span>**
- add check for connection error so plugin doesn't fail due to connection/authorization errors - otherwise plugin will prevent post processing from continuing 

**<span style="color:#56adda">0.0.1</span>**
- Initial version - based on notify_plex 0.0.5 by Josh.5
